#!/bin/sh

# shellcheck disable=SC2034
CDROOT=0
. /lib/gensplash-lib.sh
splash set_msg 'Switching to new root'

---
name: "\U0001F4D6 Documentation"
about: Suggest an improvement for documentation in Dracut
labels: 'documents'
---

**Describe the documentation**
A clear and concise description of what should be better documented.

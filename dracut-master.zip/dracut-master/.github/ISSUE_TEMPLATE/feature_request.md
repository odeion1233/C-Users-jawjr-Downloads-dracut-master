---
name: "\U00002728 Feature Request"
about: A request for enhancement in Dracut
labels: 'enhancement'
---

**Describe the enhancement**
A clear and concise description of what the enhancement is that you would like to see.
